<?php

get_template_part('inc/plugin', 'acf');

get_template_part('inc/theme', 'navigation');

get_template_part('inc/theme', 'assets');