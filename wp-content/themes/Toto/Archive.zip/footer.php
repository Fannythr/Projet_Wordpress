<footer>
    Footer
</footer>

<?php wp_footer(); ?>

</body>
</html>
